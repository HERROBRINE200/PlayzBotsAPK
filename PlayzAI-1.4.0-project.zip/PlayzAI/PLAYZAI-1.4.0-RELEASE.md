# PlayzAI 1.4.0

Production-style continuation of the Phase 2 PlayzAI project.

## Highlights

- Premium dark, light, and system theme treatment with layered clay surfaces, deep face/depth layers, bevel-like highlights, ambient shadows, press/release motion, 3D navigation, 3D chat bubbles, voice controls, Devices, Security, and Settings.
- Deep 3D clay buttons, icon buttons, switches, navigation items, composer, microphone/listening panel, device cards, security cards, and chat bubbles.
- Voice input now automatically submits a successful non-empty STT transcript exactly once, shows the user message and typing state, and uses existing TTS response playback when enabled.
- STT errors and empty results do not submit; repeated voice submissions are ignored while the same request is in flight.
- Existing authenticated backend, secure token storage, hybrid online/demo behavior, conversation history, retry/copy/share actions, SpeechRecognizer, and Android TTS preserved.
- Settings voice test and stop-speaking controls.
- English and Hindi resources kept in parity, including voice, sharing, pairing, security, and branding text.
- About section now identifies the maker as **SatyamPlayz** and describes PlayzAI.
- Authenticated backend device-status and security-event read routes added for real backend-originated Devices and Security refreshes.
- Owner-confirmed device revoke plus lockdown/unlock endpoints added; command handling remains allowlisted and does not expose arbitrary shell execution.
- Android backend URL validation requires HTTPS.

## Validation

- Backend tests: `12 passed`
- Android clean debug build: `BUILD SUCCESSFUL`
- Android debug unit tests: `BUILD SUCCESSFUL`
- Android debug lint: `BUILD SUCCESSFUL`
- APK package: `com.playzai.app`
- APK version: `1.4.0` / version code `6`
- APK signature: debug-signed; APK Signature Scheme v2 verified

## Truthful runtime boundaries

- Demo/offline mode remains explicit and does not claim remote AI or PC connectivity.
- Remote AI credentials remain backend-only. No provider credential is packaged in Android.
- A backend must be configured and authenticated before remote responses, remote device status, or backend security telemetry appear.
- The Windows pairing screen remains explicit that it does not pair a PC by itself; no fake pairing is claimed.
- No emulator or physical Android device was attached for this build, so runtime UI/device interaction was not instrumented here.
- The release build attempt was made but the Gradle daemon disappeared during dexing in this sandbox; the validated deliverable is the clean debug APK above.
