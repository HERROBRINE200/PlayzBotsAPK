"""PlayzAI backend API.

The backend owns all provider credentials. The Android client only receives a
short-lived/session or device credential and never receives AI_API_KEY.
The AI provider integration uses an OpenAI-compatible HTTP chat API configured
entirely through environment variables.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
import time
import uuid
from collections import defaultdict, deque
from contextlib import closing
from typing import Any, Callable

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

load_dotenv()

DB = os.getenv("PLAYZAI_DB", "playzai.db")
API_VERSION = "0.2.0"
BLOCK_SECONDS = int(os.getenv("AUTH_BLOCK_SECONDS", "900"))
AUTH_FAILURE_LIMIT = int(os.getenv("AUTH_FAILURE_LIMIT", "5"))
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "30"))
AUTH_RATE_LIMIT_PER_MINUTE = int(os.getenv("AUTH_RATE_LIMIT_PER_MINUTE", "12"))
AI_TIMEOUT_SECONDS = float(os.getenv("AI_TIMEOUT_SECONDS", "20"))
AI_MAX_TOKENS = int(os.getenv("AI_MAX_TOKENS", "800"))
AI_API_KEY = os.getenv("AI_API_KEY", "").strip()
AI_BASE_URL = os.getenv("AI_BASE_URL", "").strip().rstrip("/")
AI_MODEL = os.getenv("AI_MODEL", "").strip()
AUTH_SECRET = os.getenv("AUTH_SECRET", "").strip()
ENROLLMENT_SECRET = os.getenv("PLAYZAI_ENROLLMENT_SECRET", "").strip()
MASTER_KEY = os.getenv("PLAYZAI_MASTER_KEY", "").strip()
SYSTEM_PROMPT = os.getenv(
    "AI_SYSTEM_PROMPT",
    "You are PlayzAI, a helpful assistant. Be clear, safe, and concise. Never claim that an action was performed unless an authorized tool confirms it.",
)

app = FastAPI(title="PlayzAI API", version=API_VERSION)


class ProviderNotConfigured(Exception):
    pass


class ProviderUnavailable(Exception):
    pass


class ProviderTimedOut(Exception):
    pass


class ProviderRejected(Exception):
    pass


class SlidingWindowLimiter:
    """Small process-local limiter for a single development API instance.

    Production deployments should put a shared limiter such as Redis in front
    of multiple workers. This implementation still prevents accidental abuse
    and makes the behavior deterministic in tests.
    """

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def clear(self) -> None:
        self._hits.clear()

    def allow(self, key: str, limit: int, window_seconds: int = 60) -> tuple[bool, int]:
        now_value = time.time()
        hits = self._hits[key]
        while hits and hits[0] <= now_value - window_seconds:
            hits.popleft()
        if len(hits) >= max(1, limit):
            retry_after = max(1, int(hits[0] + window_seconds - now_value) + 1)
            return False, retry_after
        hits.append(now_value)
        return True, 0


limiter = SlidingWindowLimiter()


def now() -> float:
    return time.time()


def request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "unknown")


def client_ip(request: Request) -> str:
    # Forwarded headers are deliberately not trusted here. A reverse proxy
    # must overwrite request.client safely if the deployment needs real IPs.
    return request.client.host if request.client else "unknown"


def hash_credential(value: str) -> str:
    secret = AUTH_SECRET.encode("utf-8") if AUTH_SECRET else b"playzai-development-auth"
    return hmac.new(secret, value.encode("utf-8"), hashlib.sha256).hexdigest()


def safe_detail(value: str, max_length: int = 240) -> str:
    return value.replace("\n", " ").replace("\r", " ")[:max_length]


def database() -> sqlite3.Connection:
    connection = sqlite3.connect(DB, timeout=10, check_same_thread=False)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    with closing(database()) as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS devices(
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                key_hash TEXT NOT NULL,
                created REAL NOT NULL,
                last_seen REAL,
                blocked_until REAL DEFAULT 0,
                failed_attempts INTEGER DEFAULT 0,
                failed_window_start REAL DEFAULT 0
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS events(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL NOT NULL,
                source TEXT NOT NULL,
                ip TEXT NOT NULL,
                event TEXT NOT NULL,
                detail TEXT DEFAULT '',
                request_id TEXT DEFAULT ''
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions(
                id TEXT PRIMARY KEY,
                device_id TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                created REAL NOT NULL,
                expires_at REAL NOT NULL,
                revoked INTEGER DEFAULT 0
            )
            """
        )
        connection.execute("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT)")
        columns = {row[1] for row in connection.execute("PRAGMA table_info(events)").fetchall()}
        if "request_id" not in columns:
            connection.execute("ALTER TABLE events ADD COLUMN request_id TEXT DEFAULT ''")
        device_columns = {row[1] for row in connection.execute("PRAGMA table_info(devices)").fetchall()}
        if "failed_attempts" not in device_columns:
            connection.execute("ALTER TABLE devices ADD COLUMN failed_attempts INTEGER DEFAULT 0")
        if "failed_window_start" not in device_columns:
            connection.execute("ALTER TABLE devices ADD COLUMN failed_window_start REAL DEFAULT 0")
        connection.commit()


def audit(source: str, ip: str, event: str, detail: str = "", req_id: str = "") -> None:
    # Audit failures must never turn a valid API response into a 500.
    try:
        with closing(database()) as connection:
            connection.execute(
                "INSERT INTO events(ts,source,ip,event,detail,request_id) VALUES(?,?,?,?,?,?)",
                (now(), safe_detail(source, 128), safe_detail(ip, 128), safe_detail(event, 128), safe_detail(detail), safe_detail(req_id, 128)),
            )
            connection.commit()
    except sqlite3.Error:
        pass


def api_error(request: Request, code: str, message: str, status_code: int, extra_headers: dict[str, str] | None = None) -> JSONResponse:
    headers = {"X-Request-ID": request_id(request)}
    if extra_headers:
        headers.update(extra_headers)
    return JSONResponse(
        status_code=status_code,
        content={"error": {"code": code, "message": message}, "request_id": request_id(request)},
        headers=headers,
    )


def raise_api(code: str, message: str, status_code: int) -> None:
    raise HTTPException(status_code=status_code, detail={"code": code, "message": message})


def enforce_rate_limit(request: Request, key_suffix: str, limit: int | None = None) -> None:
    effective_limit = RATE_LIMIT_PER_MINUTE if limit is None else limit
    allowed, retry_after = limiter.allow(f"{client_ip(request)}:{key_suffix}", effective_limit)
    if not allowed:
        audit("rate_limiter", client_ip(request), "rate_limited", key_suffix, request_id(request))
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail={"code": "rate_limited", "message": "Too many requests. Try again later."},
            headers={"Retry-After": str(retry_after)},
        )


def require_enrollment(request: Request, supplied: str) -> None:
    if ENROLLMENT_SECRET and not hmac.compare_digest(ENROLLMENT_SECRET, supplied or ""):
        audit("enrollment", client_ip(request), "registration_denied", "invalid enrollment secret", request_id(request))
        raise_api("enrollment_required", "A valid enrollment secret is required.", status.HTTP_401_UNAUTHORIZED)


def find_device(device_id: str) -> sqlite3.Row | None:
    with closing(database()) as connection:
        return connection.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()


def record_auth_failure(device_id: str, ip: str, req_id: str, detail: str) -> None:
    with closing(database()) as connection:
        row = connection.execute("SELECT failed_attempts, failed_window_start FROM devices WHERE id=?", (device_id,)).fetchone()
        if not row:
            audit(device_id, ip, "auth_failed", detail, req_id)
            return
        start = float(row["failed_window_start"] or 0)
        attempts = int(row["failed_attempts"] or 0)
        if start <= 0 or start < now() - 300:
            start, attempts = now(), 0
        attempts += 1
        blocked_until = now() + BLOCK_SECONDS if attempts >= AUTH_FAILURE_LIMIT else 0
        connection.execute(
            "UPDATE devices SET failed_attempts=?, failed_window_start=?, blocked_until=? WHERE id=?",
            (attempts, start, blocked_until, device_id),
        )
        connection.commit()
    audit(device_id, ip, "auth_failed", detail, req_id)


def authenticate(
    request: Request,
    device_id: str | None,
    api_key: str,
    session_token: str,
) -> str:
    resolved_device_id = device_id or ""
    if session_token:
        with closing(database()) as connection:
            row = connection.execute(
                "SELECT device_id FROM sessions WHERE token_hash=? AND revoked=0 AND expires_at>?",
                (hash_credential(session_token), now()),
            ).fetchone()
        if row:
            resolved_device_id = row["device_id"]
        else:
            audit("unknown", client_ip(request), "auth_failed", "invalid session", request_id(request))
            raise_api("invalid_authentication", "Authentication failed.", status.HTTP_401_UNAUTHORIZED)

    if not resolved_device_id:
        raise_api("missing_device_id", "X-Device-ID is required.", status.HTTP_401_UNAUTHORIZED)
    row = find_device(resolved_device_id)
    if not row:
        record_auth_failure(resolved_device_id, client_ip(request), request_id(request), "unknown device")
        raise_api("invalid_authentication", "Authentication failed.", status.HTTP_401_UNAUTHORIZED)
    if row["blocked_until"] and float(row["blocked_until"]) > now():
        raise_api("device_blocked", "This device is temporarily blocked.", status.HTTP_403_FORBIDDEN)

    if session_token:
        return resolved_device_id
    if not api_key or not hmac.compare_digest(row["key_hash"], hash_credential(api_key)):
        record_auth_failure(resolved_device_id, client_ip(request), request_id(request), "invalid credential")
        raise_api("invalid_authentication", "Authentication failed.", status.HTTP_401_UNAUTHORIZED)

    with closing(database()) as connection:
        connection.execute(
            "UPDATE devices SET last_seen=?, failed_attempts=0, failed_window_start=0 WHERE id=?",
            (now(), resolved_device_id),
        )
        connection.commit()
    return resolved_device_id


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RegisterRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    name: str = Field(min_length=1, max_length=100)


class SessionRequest(StrictModel):
    device_id: str | None = Field(default=None, min_length=1, max_length=128)


class ChatRequest(StrictModel):
    message: str = Field(min_length=1, max_length=8_000)
    conversation_id: str = Field(default_factory=lambda: str(uuid.uuid4()), min_length=1, max_length=128)


class CommandRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    action: str = Field(min_length=1, max_length=64)
    args: dict[str, Any] = Field(default_factory=dict)
    confirmation: bool = False


class RevokeDeviceRequest(StrictModel):
    device_id: str = Field(min_length=1, max_length=128)
    confirmation: bool = False


SAFE_ACTIONS = {"heartbeat", "open_app", "lock_pc", "screenshot", "notify", "get_status"}
DANGEROUS_ACTIONS = {"shutdown", "restart", "delete_file", "run_command"}


async def call_ai_provider(message: str, conversation_id: str, req_id: str) -> str:
    if not AI_API_KEY or not AI_BASE_URL or not AI_MODEL:
        raise ProviderNotConfigured()
    endpoint = AI_BASE_URL if AI_BASE_URL.endswith("/chat/completions") else f"{AI_BASE_URL}/chat/completions"
    payload = {
        "model": AI_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message},
        ],
        "max_tokens": AI_MAX_TOKENS,
    }
    headers = {
        "Authorization": f"Bearer {AI_API_KEY}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Request-ID": req_id,
    }
    try:
        async with httpx.AsyncClient(timeout=AI_TIMEOUT_SECONDS) as client:
            response = await client.post(endpoint, json=payload, headers=headers)
    except httpx.TimeoutException as exc:
        raise ProviderTimedOut() from exc
    except httpx.RequestError as exc:
        raise ProviderUnavailable() from exc

    if response.status_code in (401, 403):
        audit("ai_provider", "server", "provider_auth_failed", f"status={response.status_code}", req_id)
        raise ProviderRejected()
    if response.status_code >= 500:
        audit("ai_provider", "server", "provider_unavailable", f"status={response.status_code}", req_id)
        raise ProviderUnavailable()
    if response.status_code < 200 or response.status_code >= 300:
        audit("ai_provider", "server", "provider_rejected", f"status={response.status_code}", req_id)
        raise ProviderRejected()

    try:
        body = response.json()
        reply = body["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        audit("ai_provider", "server", "provider_bad_response", "missing chat content", req_id)
        raise ProviderUnavailable() from exc
    if not isinstance(reply, str) or not reply.strip():
        raise ProviderUnavailable()
    return reply.strip()


@app.middleware("http")
async def request_context(request: Request, call_next: Callable[..., Any]) -> JSONResponse:
    supplied = request.headers.get("X-Request-ID", "").strip()
    request.state.request_id = supplied[:128] if supplied else str(uuid.uuid4())
    try:
        response = await call_next(request)
    except Exception:
        audit("server", client_ip(request), "unhandled_error", request.url.path, request_id(request))
        response = api_error(request, "internal_error", "The server could not complete the request.", 500)
    response.headers["X-Request-ID"] = request_id(request)
    audit("http", client_ip(request), "request", f"{request.method} {request.url.path} status={response.status_code}", request_id(request))
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    detail = exc.detail if isinstance(exc.detail, dict) else {"code": "request_failed", "message": str(exc.detail)}
    return api_error(request, str(detail.get("code", "request_failed")), str(detail.get("message", "Request failed.")), exc.status_code, exc.headers)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    # Locations/types are useful for clients but input values are intentionally omitted.
    fields = [".".join(str(part) for part in error.get("loc", ())) for error in exc.errors()]
    message = "Malformed request" + (f"; check {', '.join(fields[:4])}." if fields else ".")
    return api_error(request, "malformed_request", message, status.HTTP_422_UNPROCESSABLE_ENTITY)


@app.get("/health")
async def health(request: Request) -> dict[str, Any]:
    return {
        "ok": True,
        "service": "PlayzAI",
        "version": API_VERSION,
        "request_id": request_id(request),
        "provider_configured": bool(AI_API_KEY and AI_BASE_URL and AI_MODEL),
        "authenticated_api_enabled": bool(AUTH_SECRET or os.getenv("PLAYZAI_ENV", "development") != "production"),
    }


@app.post("/api/devices/register")
@app.post("/v1/devices/register")
async def register_device(
    payload: RegisterRequest,
    request: Request,
    x_enrollment_secret: str = Header(default=""),
) -> dict[str, str]:
    enforce_rate_limit(request, "register", AUTH_RATE_LIMIT_PER_MINUTE)
    require_enrollment(request, x_enrollment_secret)
    api_key = secrets.token_urlsafe(32)
    with closing(database()) as connection:
        connection.execute(
            "INSERT OR REPLACE INTO devices(id,name,key_hash,created,last_seen,blocked_until,failed_attempts,failed_window_start) VALUES(?,?,?,?,?,?,0,0)",
            (payload.device_id, payload.name, hash_credential(api_key), now(), now(), 0),
        )
        connection.commit()
    audit(payload.device_id, client_ip(request), "device_registered", payload.name, request_id(request))
    return {"device_id": payload.device_id, "api_key": api_key, "request_id": request_id(request)}


@app.post("/api/auth/session")
async def create_session(
    payload: SessionRequest,
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
) -> dict[str, Any]:
    enforce_rate_limit(request, "session", AUTH_RATE_LIMIT_PER_MINUTE)
    device_id = authenticate(request, payload.device_id or x_device_id, x_api_key, "")
    lifetime = int(os.getenv("SESSION_TTL_SECONDS", "3600"))
    token = secrets.token_urlsafe(48)
    expires_at = now() + max(60, lifetime)
    with closing(database()) as connection:
        connection.execute(
            "INSERT INTO sessions(id,device_id,token_hash,created,expires_at,revoked) VALUES(?,?,?,?,?,0)",
            (str(uuid.uuid4()), device_id, hash_credential(token), now(), expires_at),
        )
        connection.commit()
    audit(device_id, client_ip(request), "session_created", "session token issued", request_id(request))
    return {"session_token": token, "device_id": device_id, "expires_at": expires_at, "request_id": request_id(request)}


@app.get("/api/auth/status")
async def auth_status(
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
    x_session_token: str = Header(default=""),
) -> dict[str, Any]:
    device_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    return {"authenticated": True, "device_id": device_id, "request_id": request_id(request)}


@app.get("/v1/devices")
@app.get("/api/devices")
async def list_devices(
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
    x_session_token: str = Header(default=""),
) -> dict[str, Any]:
    current_device = authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT id,name,created,last_seen,blocked_until FROM devices ORDER BY created ASC").fetchall()
    devices = []
    for row in rows:
        last_seen = float(row["last_seen"]) if row["last_seen"] else None
        blocked = bool(row["blocked_until"] and float(row["blocked_until"]) > now())
        devices.append({
            "device_id": row["id"],
            "name": row["name"],
            "status": "blocked" if blocked else ("online" if last_seen and now() - last_seen <= 120 else "offline"),
            "last_seen": last_seen,
            "authenticated": row["id"] == current_device,
        })
    return {"devices": devices, "request_id": request_id(request)}


@app.get("/v1/security/events")
@app.get("/api/security/events")
async def security_events(
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
    x_session_token: str = Header(default=""),
) -> dict[str, Any]:
    authenticate(request, x_device_id, x_api_key, x_session_token)
    with closing(database()) as connection:
        rows = connection.execute("SELECT id,ts,source,ip,event,detail,request_id FROM events ORDER BY id DESC LIMIT 100").fetchall()
    events = [dict(row) for row in rows]
    return {"events": events, "request_id": request_id(request)}


@app.post("/api/chat")
@app.post("/v1/chat")
async def chat(
    payload: ChatRequest,
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
    x_session_token: str = Header(default=""),
) -> dict[str, str]:
    device_id = authenticate(request, x_device_id, x_api_key, x_session_token)
    enforce_rate_limit(request, f"chat:{device_id}")
    try:
        reply = await call_ai_provider(payload.message, payload.conversation_id, request_id(request))
    except ProviderNotConfigured:
        audit(device_id, client_ip(request), "chat_failed", "AI provider not configured", request_id(request))
        raise_api("provider_not_configured", "The AI provider is not configured on the backend.", status.HTTP_503_SERVICE_UNAVAILABLE)
    except ProviderTimedOut:
        audit(device_id, client_ip(request), "chat_timeout", "AI provider timeout", request_id(request))
        raise_api("provider_timeout", "The AI provider timed out. Try again later.", status.HTTP_504_GATEWAY_TIMEOUT)
    except ProviderRejected:
        audit(device_id, client_ip(request), "chat_failed", "AI provider rejected request", request_id(request))
        raise_api("provider_error", "The AI provider rejected the request.", status.HTTP_502_BAD_GATEWAY)
    except ProviderUnavailable:
        audit(device_id, client_ip(request), "chat_failed", "AI provider unavailable", request_id(request))
        raise_api("provider_unavailable", "The AI provider is temporarily unavailable.", status.HTTP_503_SERVICE_UNAVAILABLE)
    audit(device_id, client_ip(request), "chat_completed", f"conversation={payload.conversation_id}", request_id(request))
    return {"reply": reply, "conversation_id": payload.conversation_id, "request_id": request_id(request)}


def command_impl(
    payload: CommandRequest,
    request: Request,
    x_device_id: str,
    x_api_key: str,
    x_session_token: str,
) -> dict[str, Any]:
    device_id = authenticate(request, x_device_id or payload.device_id, x_api_key, x_session_token)
    enforce_rate_limit(request, f"command:{device_id}")
    if payload.action not in SAFE_ACTIONS and not (payload.action in DANGEROUS_ACTIONS and payload.confirmation):
        audit(device_id, client_ip(request), "command_denied", payload.action, request_id(request))
        return {"ok": False, "requires_confirmation": True, "action": payload.action, "request_id": request_id(request)}
    audit(device_id, client_ip(request), "command_accepted", payload.action, request_id(request))
    return {"ok": True, "queued": True, "action": payload.action, "args": payload.args, "request_id": request_id(request)}


@app.post("/v1/command")
@app.post("/api/command")
async def command(
    payload: CommandRequest,
    request: Request,
    x_device_id: str = Header(default=""),
    x_api_key: str = Header(default=""),
    x_session_token: str = Header(default=""),
) -> dict[str, Any]:
    return command_impl(payload, request, x_device_id, x_api_key, x_session_token)


def require_master_key(request: Request, supplied: str) -> None:
    if not MASTER_KEY or not hmac.compare_digest(MASTER_KEY, supplied or ""):
        audit("owner", client_ip(request), "owner_auth_failed", "invalid master key", request_id(request))
        raise_api("invalid_authentication", "Authentication failed.", status.HTTP_401_UNAUTHORIZED)


@app.post("/api/devices/revoke")
async def revoke_device(
    payload: RevokeDeviceRequest,
    request: Request,
    x_api_key: str = Header(default=""),
) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    if not payload.confirmation:
        return {"ok": False, "requires_confirmation": True, "device_id": payload.device_id, "request_id": request_id(request)}
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=? WHERE id=?", (now() + BLOCK_SECONDS, payload.device_id))
        connection.execute("UPDATE sessions SET revoked=1 WHERE device_id=?", (payload.device_id,))
        connection.commit()
    audit("owner", client_ip(request), "device_revoked", payload.device_id, request_id(request))
    return {"ok": True, "device_id": payload.device_id, "blocked_for_seconds": BLOCK_SECONDS, "request_id": request_id(request)}


@app.post("/api/security/lockdown")
async def lockdown(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=?", (now() + BLOCK_SECONDS,))
        connection.execute("UPDATE sessions SET revoked=1")
        connection.commit()
    audit("owner", client_ip(request), "lockdown_enabled", "all devices and sessions temporarily blocked", request_id(request))
    return {"ok": True, "blocked_for_seconds": BLOCK_SECONDS, "request_id": request_id(request)}


@app.post("/api/security/unlock")
async def unlock(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    require_master_key(request, x_api_key)
    with closing(database()) as connection:
        connection.execute("UPDATE devices SET blocked_until=0, failed_attempts=0, failed_window_start=0")
        connection.execute("UPDATE sessions SET revoked=1")
        connection.commit()
    audit("owner", client_ip(request), "lockdown_disabled", "devices unblocked; re-authentication required", request_id(request))
    return {"ok": True, "reauthentication_required": True, "request_id": request_id(request)}


@app.post("/v1/security/panic")
@app.post("/api/security/panic")
async def panic(request: Request, x_api_key: str = Header(default="")) -> dict[str, Any]:
    return await lockdown(request, x_api_key)


init_db()
