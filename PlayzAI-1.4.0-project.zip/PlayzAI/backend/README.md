# PlayzAI backend

The backend is the only component that talks to an AI provider. The Android APK never contains `AI_API_KEY`.

## Configure

```bash
cd backend
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Set these values in the backend environment only:

- `AI_API_KEY`: provider credential; never put it in Android or source control.
- `AI_BASE_URL`: an authorized OpenAI-compatible API base URL. Leave blank until configured.
- `AI_MODEL`: provider model identifier.
- `AUTH_SECRET`: long random secret used to hash device keys and sessions.
- `PLAYZAI_ENROLLMENT_SECRET`: optional enrollment protection for device registration.
- `PLAYZAI_MASTER_KEY`: owner-only key for panic lockdown.

The server deliberately returns `503 provider_not_configured` if the provider variables are blank. It does not fabricate AI replies.

## Run

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

Use TLS termination at a hardened reverse proxy for deployment. The app supports HTTPS URLs; do not expose the development HTTP server directly to the public internet.

## Device enrollment

Development enrollment, when `PLAYZAI_ENROLLMENT_SECRET` is empty:

```bash
curl -X POST http://127.0.0.1:8000/api/devices/register \
  -H 'Content-Type: application/json' \
  -d '{"device_id":"phone-001","name":"My Android phone"}'
```

When an enrollment secret is configured, add:

```text
X-Enrollment-Secret: <the configured secret>
```

The returned `api_key` is shown only once. Store it in the Android app's secure backend authentication settings. Never log or commit it.

## Chat request

```bash
curl -X POST https://your-backend.example/api/chat \
  -H 'Content-Type: application/json' \
  -H 'X-Device-ID: phone-001' \
  -H 'X-API-Key: <device api key>' \
  -d '{"message":"नमस्ते PlayzAI","conversation_id":"local-conversation-id"}'
```

Response:

```json
{
  "reply": "...",
  "conversation_id": "local-conversation-id",
  "request_id": "..."
}
```

The provider adapter sends UTF-8 JSON and accepts Hindi, English, and other Unicode text supported by the provider.

## Endpoints

- `GET /health` — unauthenticated health/configuration status; never returns secrets.
- `POST /api/devices/register` — enroll a device; optionally protected by `PLAYZAI_ENROLLMENT_SECRET`.
- `POST /api/auth/session` — exchange a device API key for a time-limited session token.
- `GET /api/auth/status` — verify device/session authentication.
- `GET /api/devices` — authenticated registered-device status list.
- `GET /api/security/events` — authenticated backend audit/security telemetry.
- `POST /api/chat` — authenticated AI chat endpoint.
- `POST /api/command` — authenticated allowlisted command queue; no arbitrary shell execution.
- `POST /api/devices/revoke` — owner-confirmed device revocation with a temporary block.
- `POST /api/security/lockdown` and `/api/security/unlock` — owner master-key lockdown controls.
- `POST /api/security/panic` — compatibility alias for owner master-key lockdown; revokes sessions and temporarily blocks devices.

The original `/v1/...` routes remain available for compatibility with existing agent integrations.

## Development tests

```bash
pytest -q
```

Tests use a mocked provider boundary for deterministic English/Hindi contract tests. A real provider request is only possible after setting valid backend-only provider variables; no credential is included in this repository.
