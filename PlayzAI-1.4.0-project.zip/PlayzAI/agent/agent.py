import os, time, json, platform, subprocess, urllib.request

API=os.getenv('PLAYZAI_API','http://127.0.0.1:8000')
DEVICE_ID=os.getenv('PLAYZAI_DEVICE_ID','local-pc')
API_KEY=os.getenv('PLAYZAI_API_KEY','')

def post(path,payload):
    data=json.dumps(payload).encode(); req=urllib.request.Request(API+path,data=data,headers={'Content-Type':'application/json','X-API-Key':API_KEY},method='POST')
    with urllib.request.urlopen(req,timeout=10) as r: return json.loads(r.read())

def local_action(action,args):
    if action=='lock_pc' and platform.system()=='Windows':
        subprocess.Popen(['rundll32.exe','user32.dll,LockWorkStation'])
        return {'ok':True}
    if action=='open_app':
        # Only permit explicitly configured executables; never pass arbitrary shell strings.
        allow={'notepad':'notepad.exe','calc':'calc.exe'}
        name=args.get('name','').lower()
        if name not in allow: return {'ok':False,'error':'application not allowlisted'}
        subprocess.Popen([allow[name]]); return {'ok':True}
    if action in ('heartbeat','get_status'): return {'ok':True,'platform':platform.platform()}
    return {'ok':False,'error':'unsupported local action'}

def main():
    print('PlayzAI agent running. Use a service manager only after reviewing permissions.')
    while True:
        try:
            # Heartbeat only; a production agent should receive signed, short-lived tasks over WebSocket.
            post('/v1/command',{'device_id':DEVICE_ID,'action':'heartbeat','args':{}})
        except Exception as e: print('heartbeat:',e)
        time.sleep(30)

if __name__=='__main__': main()
