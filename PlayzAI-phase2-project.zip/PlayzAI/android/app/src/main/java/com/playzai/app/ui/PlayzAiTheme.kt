package com.playzai.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.playzai.app.model.AppThemeMode

private val LightColors = lightColorScheme(
    primary = Color(0xFF4E55D9),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE2E3FF),
    onPrimaryContainer = Color(0xFF11145F),
    secondary = Color(0xFF5A5D72),
    tertiary = Color(0xFF76546D)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFC1C3FF),
    onPrimary = Color(0xFF272A7D),
    primaryContainer = Color(0xFF393C91),
    onPrimaryContainer = Color(0xFFE2E3FF),
    secondary = Color(0xFFC3C4DD),
    tertiary = Color(0xFFE7B9D7)
)

@Composable
fun PlayzAiTheme(theme: AppThemeMode, content: @Composable () -> Unit) {
    val dark = when (theme) {
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
