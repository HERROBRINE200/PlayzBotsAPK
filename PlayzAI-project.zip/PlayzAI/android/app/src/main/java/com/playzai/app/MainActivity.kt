package com.playzai.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val v=TextView(this)
        v.text="PlayzAI\n\n● Security-first client\n\nVoice, text, device management and security alerts will connect to the backend."
        v.textSize=22f
        v.setPadding(40,80,40,40)
        setContentView(v)
    }
}
