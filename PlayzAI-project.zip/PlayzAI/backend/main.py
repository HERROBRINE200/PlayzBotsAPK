import os, sqlite3, secrets, hashlib, time, ipaddress
from datetime import datetime, timezone
from fastapi import FastAPI, Request, HTTPException, Header
from pydantic import BaseModel

DB = os.getenv('PLAYZAI_DB', 'playzai.db')
app = FastAPI(title='PlayzAI API', version='0.1.0')

BLOCK_SECONDS = 3600
MAX_FAILS = 5

def db():
    c=sqlite3.connect(DB)
    c.execute('CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY, name TEXT, key_hash TEXT, created REAL, last_seen REAL, blocked_until REAL DEFAULT 0)')
    c.execute('CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, source TEXT, ip TEXT, event TEXT, detail TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT)')
    c.commit(); return c

def h(x): return hashlib.sha256(x.encode()).hexdigest()
def now(): return time.time()
def log(source, ip, event, detail=''):
    c=db(); c.execute('INSERT INTO events(ts,source,ip,event,detail) VALUES(?,?,?,?,?)',(now(),source,ip,event,detail)); c.commit(); c.close()

def get_client_ip(req):
    # Do not trust forwarded headers unless your reverse proxy overwrites them safely.
    return req.client.host if req.client else 'unknown'

class Register(BaseModel):
    device_id: str
    name: str

class Command(BaseModel):
    device_id: str
    action: str
    args: dict = {}
    confirmation: bool = False

SAFE_ACTIONS={'heartbeat','open_app','lock_pc','screenshot','notify','get_status'}
DANGEROUS={'shutdown','restart','delete_file','run_command'}

@app.get('/health')
def health(): return {'ok':True,'service':'PlayzAI'}

@app.post('/v1/devices/register')
def register(x:Register, request:Request):
    if len(x.device_id)>128 or len(x.name)>100: raise HTTPException(400,'Invalid device data')
    key=secrets.token_urlsafe(32)
    c=db(); c.execute('INSERT OR REPLACE INTO devices(id,name,key_hash,created,last_seen,blocked_until) VALUES(?,?,?,?,?,0)',(x.device_id,x.name,h(key),now(),now())); c.commit(); c.close()
    log(x.device_id,get_client_ip(request),'device_registered',x.name)
    return {'device_id':x.device_id,'api_key':key}

def auth(device_id, api_key, ip):
    c=db(); row=c.execute('SELECT key_hash,blocked_until FROM devices WHERE id=?',(device_id,)).fetchone(); c.close()
    if not row: log(device_id,ip,'auth_failed','unknown device'); raise HTTPException(401,'Authentication failed')
    if row[1] and row[1]>now(): raise HTTPException(403,'Device temporarily blocked')
    if not api_key or not secrets.compare_digest(row[0],h(api_key)):
        # Block the device after repeated failures in a simple time window.
        log(device_id,ip,'auth_failed','invalid credential')
        raise HTTPException(401,'Authentication failed')

def update_seen(device_id):
    c=db(); c.execute('UPDATE devices SET last_seen=? WHERE id=?',(now(),device_id)); c.commit(); c.close()

def alert_payload(device_id, ip, event, detail):
    return {'type':'security_alert','device_id':device_id,'observed_ip':ip,'event':event,'detail':detail,'action':'BLOCKED','decision_options':['UNBLOCK','KEEP_BLOCKED']}

@app.post('/v1/command')
def command(x:Command, request:Request, x_api_key: str=Header(default='')):
    ip=get_client_ip(request); auth(x.device_id,x_api_key,ip); update_seen(x.device_id)
    if x.action not in SAFE_ACTIONS and not (x.action in DANGEROUS and x.confirmation):
        log(x.device_id,ip,'command_denied',x.action)
        return {'ok':False,'requires_confirmation':True,'action':x.action}
    log(x.device_id,ip,'command_accepted',x.action)
    return {'ok':True,'queued':True,'action':x.action,'args':x.args}

@app.post('/v1/security/panic')
def panic(request:Request, x_api_key: str=Header(default='')):
    # Master key is only for the owner/admin and must be stored outside source in production.
    master=os.getenv('PLAYZAI_MASTER_KEY','')
    if not master or not secrets.compare_digest(master,x_api_key): raise HTTPException(401,'Unauthorized')
    c=db(); c.execute('UPDATE devices SET blocked_until=?',(now()+BLOCK_SECONDS,)); c.commit(); c.close()
    log('owner',get_client_ip(request),'panic_mode','all devices temporarily blocked')
    return {'ok':True,'blocked_for_seconds':BLOCK_SECONDS}
