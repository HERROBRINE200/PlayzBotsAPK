# PlayzAI
Personal AI control platform: cloud backend + Windows agent + Android app scaffold.

## Security model
- Device authentication with per-device API keys.
- Tool allowlist: no arbitrary remote shell from the AI.
- Rate limiting and temporary IP/device blocking.
- Audit logging.
- Security alerts expose only network identifiers actually observed by the backend.
- Dangerous actions require confirmation.
- Panic mode revokes active device sessions.

## Components
- `backend/`: FastAPI API, SQLite database, security engine, task router.
- `agent/`: Windows Python agent with safe local tools and heartbeat.
- `android/`: Android Kotlin client scaffold.
- `config/`: example configuration.

This is a security-first MVP foundation. Production deployment requires TLS, a real secrets manager, provider credentials, Android signing, and review of OS permissions.
